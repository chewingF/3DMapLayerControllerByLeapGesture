﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HandleMetaphor:TouchableObject{
    
    private List<LayerMetaphor> layers = new List<LayerMetaphor>();
    private GameObject baseObject;
    private float generalGap = 0.1f;

    public HandleMetaphor(GameObject handleGo)
    {
        worldObject = handleGo;
        foreach (Transform t in handleGo.transform)
        {
            if (t.name == "Base")
            {
                baseObject = t.gameObject;
                Debug.Log("Base found");
            }
        }
    }

    public void addLayer(LayerMetaphor layer)
    {
        try
        {
            GameObject layerObject = layer.getMetaphorObject();
            layerObject.transform.parent = baseObject.transform.parent;
        }
        catch
        {
            Debug.Log("Fail to set layer parent");
            return;
        }
        layers.Add(layer);
    }

    public void removeLayer(LayerMetaphor layer)
    {
        try
        {
            GameObject layerObject = layer.getMetaphorObject();
            layerObject.transform.parent = worldObject.transform.parent;
        }
        catch
        {
            Debug.Log("Fail to set layer parent");
            return;
        }
        layers.Remove(layer);
    }

    public void updateObjectsPositions()
    {
        int i = 0;
        foreach (LayerMetaphor layer in layers){
            i++;
            if (!layer.IsPinched)
            {
                layer.moveObjectTo(postionForLayerInIndex(i));
            }
        }
    }

    private Vector3 postionForLayerInIndex(int i)
    {
        Vector3 newPos = new Vector3();
        newPos = baseObject.transform.position;
        Debug.Log(newPos);
        newPos.y = newPos.y + (i * (newPos.y - worldObject.transform.position.y));
        return newPos;
    }

    public bool updateLayerExisted(LayerMetaphor lm)
    {
        Vector3 lmPos = lm.getMetaphorObject().transform.position;
        Vector3 handlePos = getMetaphorObject().transform.position;
        float distance = Vector2.Distance(new Vector2(lmPos.x, lmPos.z), new Vector2(handlePos.x, handlePos.z));
        //bool inRange = (distance <= pinchingRange * 2);
        bool inRange = (distance <= baseObject.transform.GetComponent<CapsuleCollider>().radius * baseObject.transform.lossyScale.x);
        if (layers.Contains(lm))
        {
            if (!inRange)
            {
                removeLayer(lm);
            }
        }
        else
        {
            if (inRange)
            {
                addLayer(lm);
            }
        }
        return inRange;
    }

    public void updateObjectsOrder()
    {
        List<LayerMetaphor> newLayers = new List<LayerMetaphor>();
        for(int i = 0; i < layers.Count-1 ; i++)
        {
            for(int j = i+1; j < layers.Count; j++)
            {
                if(layers[j].getMetaphorObject().transform.position.y < layers[i].getMetaphorObject().transform.position.y)
                {
                    LayerMetaphor temp = layers[j];
                    layers[j] = layers[i];
                    layers[i] = temp;
                }
            }
        }
    }
}
