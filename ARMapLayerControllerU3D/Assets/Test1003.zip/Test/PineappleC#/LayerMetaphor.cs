﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LayerMetaphor : TouchableObject {

    private MapARLayer layer;
    private List<SelectionMetaphor> selectionObjects = new List<SelectionMetaphor>();

    public LayerMetaphor()
    {
    }

    public LayerMetaphor(MapARLayer layer)
    {
        this.layer = layer;
        initMetaphorObject();
    }

    public LayerMetaphor(MapARLayer layer, GameObject metaphorObject)
    {
        this.layer = layer;
        this.worldObject = metaphorObject;
    }

    private void initMetaphorObject()
    {
        if (layer == null)
        {
            return;
        }
        GameObject cylinder = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        cylinder.name = layer.getLayerName().ToUpper();
        cylinder.transform.localScale = new Vector3(.25f, .025f, .25f);
        cylinder.AddComponent<MeshCollider>();
        GameObject.Destroy(cylinder.GetComponent<CapsuleCollider>());
        Material newMaterial = (Material)Resources.Load("Text_" + layer.getLayerName(), typeof(Material));
        cylinder.GetComponent<Renderer>().material = newMaterial;
        worldObject = cylinder;
        worldObject.transform.Rotate(Vector3.up, 120);
    }

    public void createSelections()
    {
        List<string> attributes = layer.getMapAttributes();
        int count = 0;
        foreach (string attStr in attributes)
        {
            SelectionMetaphor sm = new SelectionMetaphor(this,0.7f, attStr);
            sm.rotateBy(60 * count);
            selectionObjects.Add(sm);
            count++;
        }
    }

    public void createSelections(string selectionStr)
    {
        removeSelections();
        List<string> attributes = new List<string>();
        if (selectionStr == "COLOR")
        {
            attributes.Add("Red");
            attributes.Add("Yellow");
            attributes.Add("Blue");
        }
        else if (selectionStr == "RED")
        {
            layer.setColor(Color.red);
        }
        else if (selectionStr == "YELLOW")
        {
            layer.setColor(Color.yellow);
        }
        else if (selectionStr == "BLUE")
        {
            layer.setColor(Color.blue);
        }
        else if (selectionStr == "TRANSPARENCY")
        {
            attributes.Add("25");
            attributes.Add("50");
            attributes.Add("75");
            attributes.Add("100");
        }
        else if (selectionStr == "25")
        {
            layer.setTransparency(25);
        }
        else if (selectionStr == "25")
        {
            layer.setTransparency(25);
        }
        else if (selectionStr == "50")
        {
            layer.setTransparency(50);
        }
        else if (selectionStr == "100")
        {
            layer.setTransparency(100);
        }
        int count = 0;
        foreach (string attStr in attributes)
        {
            SelectionMetaphor sm = new SelectionMetaphor(this, 1.2f, attStr);
            //sm.rotateBy(30 * count);
            sm.pushTo(1.2f+0.2f*count);
            selectionObjects.Add(sm);
            count++;
        }
    }

    public void removeSelections() {
        foreach (SelectionMetaphor sm in selectionObjects)
        {
            GameObject.Destroy(sm.getMetaphorObject());
        }
        selectionObjects.Clear();
    }

    public MapARLayer getLayer()
    {
        return layer;
    }

    public void reScaleWorldObj(float rateX, float rateY, float rateZ)
    {
        Vector3 newScale = worldObject.transform.localScale;
        newScale.x = newScale.x * rateX;
        newScale.y = newScale.y * rateY;
        newScale.z = newScale.z * rateZ;
        worldObject.transform.localScale = newScale;
    }

    public List<SelectionMetaphor> getSelectionObjects()
    {
        return selectionObjects;
    }
}
