﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mapbox.Unity.Map;
using Leap;
using Mapbox.Map;
using System.Linq;
using Leap.Unity;
using UnityEngine.UI;

public class LayerManager : MonoBehaviour {

    private GameObject mapObj = null;
    private AbstractMap mapToEdit;
    private bool Lock = true;//lock other operation when the map is building or animating

    //private List<MapARLayer> mapARLayersActived = new List<MapARLayer>();
    //private List<MapARLayer> mapARLayersDisActived = new List<MapARLayer>();

    private HandleMetaphor handle;
    private List<LayerMetaphor> layerMetaphorsActived = new List<LayerMetaphor>();
    private List<LayerMetaphor> layerMetaphorsDisActived = new List<LayerMetaphor>();


    //Leap stuffs
    private Controller controller;
    public LeapProvider _leapProvider;
    //gesture models
    private LeapGestureModel gestureGrabbingRH, gestureGrabbingLH,
        gestureGrabRH, gestureGrabLH,
        //gestureGrabReleaseRH, gestureGrabReleaseLH,
        gesturePinchRH, gesturePinchLH,
        gesturePinchingRH, gesturePinchingLH,
        //gesturePinchReleaseRH, gesturePinchReleaseLH,
        gestureTappingRH, gestureTappingLH;

    //Grab stuffs
    private HandleMetaphor goGrabbedRH, goGrabbedLH;
    private LayerMetaphor goPinchedRH, goPinchedLH, goTappedRH, goTappedLH, goTappingRH, goTappingLH;

    //Info Panel
    public GameObject infoPanel;

    //Control mode   
    private enum ControlMode
    {
        tappingRotation,
        tapMenu
    }
    [SerializeField]
    ControlMode controlMode;


    // Use this for initialization
    void Start()
    {
        MapLayerInit();
        LeapInit();
        HandleInit();
        HandleUpdate();
    }

    // Update is called once per frame
    void Update()
    {
        LayerUpdate();
        GestureListener();
        //HandleUpdate();
        InfoUpdate();
    }

    private void MapLayerInit()
    {
        foreach (GameObject gameObj in GameObject.FindObjectsOfType<GameObject>())
        {
            if (gameObj.name == "Map")
            {
                mapObj = gameObj;
            }
        }

        if (mapObj != null)
        {
            mapToEdit = mapObj.GetComponent<AbstractMap>();
            List<VectorSubLayerProperties> mapLayerProperties = mapToEdit.VectorData.LayerProperty.vectorSubLayers;
            foreach (VectorSubLayerProperties vsp in mapLayerProperties)
            {
                MapARLayer newLayer = new MapARLayer(vsp);
                if (vsp.coreOptions.isActive)
                {
                    LayerMetaphor newMetaphor = new LayerMetaphor(newLayer);
                    layerMetaphorsActived.Add(newMetaphor);
                }
            }
        }
    }

    private void LeapInit()
    {
        _leapProvider = GameObject.FindObjectOfType<LeapProvider>(); //GetTransformGestureManagerBasedMode().GetComponentInChildren<LeapProvider>();

        //set up all gesture models
        gestureGrabbingLH = new GestureGrabbing();
        gestureGrabbingRH = new GestureGrabbing();
        gestureGrabLH = new GestureGrab();
        gestureGrabRH = new GestureGrab();
        //gestureGrabReleaseLH = new GestureGrabRelease();
        //gestureGrabReleaseRH = new GestureGrabRelease();
        gesturePinchingLH = new GesturePinching();
        gesturePinchingRH = new GesturePinching();
        gesturePinchLH = new GesturePinch();
        gesturePinchRH = new GesturePinch();
        //gesturePinchReleaseLH = new GesturePinchRelease();
        //gesturePinchReleaseRH = new GesturePinchRelease();
        gestureTappingLH = new GestureTapping();
        gestureTappingRH = new GestureTapping();
    }

    private void HandleInit()
    {
        GameObject handleGo = GameObject.Find("Handle");
        //Debug.Log(handleGo == null);
        handle = new HandleMetaphor(handleGo);
        //Debug.Log(handle.getMetaphorObject() == null);
        foreach (LayerMetaphor layer in layerMetaphorsActived)
        {
            handle.addLayer(layer);
        }
    }

    //update layer gameobject content when map initialized , moved.
    private void LayerUpdate()
    {
        //check initialized
        var visualizer = mapToEdit.MapVisualizer;
        visualizer.OnMapVisualizerStateChanged += (s) =>
        {

            if (this == null)
                return;

            if (s == ModuleState.Finished)
            {
                if (this.Lock)
                {
                    foreach (LayerMetaphor lm in this.layerMetaphorsActived)
                    {
                        lm.getLayer().updatLayerGameObjects();
                    }
                    this.Lock = false;
                }
            }
            else if (s == ModuleState.Working)
            {
                this.Lock = true;
            }
        };
    }


    private void GestureListener()
    { //not editable when building
        if (this.Lock)
        {
            return;
        }
        else
        {
            controller = new Controller();
            Frame frame = _leapProvider.CurrentFrame;
            List<Hand> hands = frame.Hands;
            Hand leftHand = new Hand();
            bool leftHandExist = false;
            Hand rightHand = new Hand();
            bool rightHandExist = false;
            foreach (Hand hand in hands)
            {
                if (hand.IsLeft)
                {
                    leftHand = hand;
                    leftHandExist = true;
                }
                else
                {
                    rightHand = hand;
                    rightHandExist = true;
                }
            }
            //One-Hand Gestures for Left Hand
            if (leftHandExist)
            {
                LeapGestureModel.State stateGrabLH = gestureGrabLH.Check(leftHand, null, Time.deltaTime);
                LeapGestureModel.State stateGrabbingLH = gestureGrabbingLH.Check(leftHand, null, Time.deltaTime);
                LeapGestureModel.State statePinchLH = gesturePinchLH.Check(leftHand, null, Time.deltaTime);
                LeapGestureModel.State statePinchingLH = gesturePinchingLH.Check(leftHand, null, Time.deltaTime);
                LeapGestureModel.State stateTappingLH = gestureTappingLH.Check(leftHand, null, Time.deltaTime);
                if (stateGrabLH == LeapGestureModel.State.End)
                {
                    OneHandGrab(0);
                }
                if (stateGrabbingLH == LeapGestureModel.State.InProcess)
                {
                    OneHandGrabbing(0);
                }
                if (stateGrabbingLH == LeapGestureModel.State.End)
                {
                    OneHandEndGrabbing(0);
                }
                if (statePinchLH == LeapGestureModel.State.End)
                {
                    OneHandPinch(0);
                }
                if (statePinchingLH == LeapGestureModel.State.InProcess)
                {
                    OneHandPinching(0);
                }
                if (statePinchingLH== LeapGestureModel.State.End)
                {
                    OneHandEndPinching(0);
                }
                if (stateTappingLH == LeapGestureModel.State.InProcess)
                {
                    OneHandTapping(0);
                }
                if (stateTappingLH == LeapGestureModel.State.End)
                {
                    OneHandEndTapping(0);
                }
            }
            //One-Hand Gestures for Right Hand
            else if (rightHandExist)
            {
                LeapGestureModel.State stateGrabRH = gestureGrabRH.Check(null, rightHand, Time.deltaTime);
                LeapGestureModel.State stateGrabbingRH = gestureGrabbingRH.Check(null, rightHand, Time.deltaTime);
                LeapGestureModel.State statePinchRH = gesturePinchRH.Check(null, rightHand, Time.deltaTime);
                LeapGestureModel.State statePinchingRH = gesturePinchingRH.Check(null, rightHand, Time.deltaTime);
                LeapGestureModel.State stateTappingRH = gestureTappingRH.Check(null, rightHand, Time.deltaTime);
                if (stateGrabRH == LeapGestureModel.State.End)
                {
                    OneHandGrab(1);
                }
                if (stateGrabbingRH == LeapGestureModel.State.InProcess)
                {
                    OneHandGrabbing(1);
                }
                if (stateGrabbingRH == LeapGestureModel.State.End)
                {
                    OneHandEndGrabbing(1);
                }
                if (statePinchRH == LeapGestureModel.State.End)
                {              
                    OneHandPinch(1);
                }
                if (statePinchingRH == LeapGestureModel.State.InProcess)
                {
                    OneHandPinching(1);
                }
                if (statePinchingRH == LeapGestureModel.State.End)
                {
                    OneHandEndPinching(1);
                }
                if (stateTappingRH == LeapGestureModel.State.InProcess)
                {
                    OneHandTapping(1);
                }
                if (stateTappingRH == LeapGestureModel.State.End)
                {
                    OneHandEndTapping(1);
                }
            }
        }
    }

    private void HandleUpdate()
    {
        if (handle == null)
        {
            return;
        }
        handle.updateObjectsPositions();
    }

    private void InfoUpdate()
    {
        string info = "";
        if (goTappedRH == null)
        {
            info += "TapRH: null";
        }
        else
        {
            info += "TapRH: " + goTappedRH.getMetaphorObject().name;
        }
        if (goTappingRH == null)
        {
            info += "\nTappingRH: null";
        }
        else
        {
            info += "\nTappingRH: " + goTappingRH.getMetaphorObject().name;
        }
        try
        {
            GestureTapping gesture = (GestureTapping)gestureTappingRH;
            Vector3 tappingPos = gesture.LastTipPos;
            foreach (LayerMetaphor lm in layerMetaphorsActived)
            {
                GameObject worldObject = lm.getMetaphorObject();
                Collider coll = worldObject.GetComponent<Collider>();
                Vector3 closestPoint = coll.ClosestPointOnBounds(tappingPos);
                float distance = Vector3.Distance(closestPoint, tappingPos);
                info += "\n" + lm.getMetaphorObject().name + " distance: " + distance.ToString();
            }
        }
        catch
        {

        }
        infoPanel.GetComponent<Text>().text = info;
    }

    private void OneHandGrab(int mode)
    {
        GestureGrab gesture;
        Vector3 grabbingPos;
        switch (mode)
        {
            case 0:
                gesture = (GestureGrab)gestureGrabLH;
                grabbingPos = gesture.LastPalmPos;
                Debug.Log("handle" + handle.getMetaphorObject() == null);
                if (handle.checkGrabbing(grabbingPos))
                {
                    goGrabbedLH = handle;
                    handle.startGrab();
                }
                return;
            case 1:
                gesture = (GestureGrab)gestureGrabRH;
                grabbingPos = gesture.LastPalmPos;
                if (handle.checkGrabbing(grabbingPos))
                {
                    goGrabbedRH = handle;
                    handle.startGrab();
                }
                return;
        }
    }

    private void OneHandGrabbing(int mode)
    {
        GestureGrabbing gesture;
        Vector3 grabbingPos;
        Vector3 posMovement;
        switch (mode)
        {
            case 0:
                gesture = (GestureGrabbing)gestureGrabbingLH;
                grabbingPos = gesture.LastPalmPos;
                posMovement = gesture.PalmMovement;
                if (goGrabbedLH != null)
                {
                    goGrabbedLH.moveObjectBy(posMovement);
                }
                return;
            case 1:
                gesture = (GestureGrabbing)gestureGrabbingRH;
                grabbingPos = gesture.LastPalmPos;
                posMovement = gesture.PalmMovement;
                if (goGrabbedRH != null)
                {
                    goGrabbedRH.moveObjectBy(posMovement);
                }
                return;
        }
    }

    private void OneHandPinch(int mode)
    {
        GesturePinch gesture;
        Vector3 pinchingPos;
        List<LayerMetaphor> potentialLayers;
        switch (mode)
        {
            case 0:
                if (goPinchedLH != null)
                {
                    return;
                }
                potentialLayers = new List<LayerMetaphor>();
                gesture = (GesturePinch)gesturePinchLH;
                pinchingPos = gesture.LastTipPos;
                foreach (LayerMetaphor lm in layerMetaphorsActived)
                {
                    if (!lm.IsPinched)
                    {
                        if (lm.checkPinching(pinchingPos))
                        {
                            potentialLayers.Add(lm);
                        }
                    }
                }
                foreach (LayerMetaphor lm in layerMetaphorsDisActived)
                {
                    if (!lm.IsPinched)
                    {
                        if (lm.checkPinching(pinchingPos))
                        {
                            potentialLayers.Add(lm);
                        }
                    }
                }
                if (potentialLayers.Count > 0)
                {
                    goPinchedLH = potentialLayers[0];
                    goPinchedLH.startPinch();
                    foreach(LayerMetaphor lm in potentialLayers)
                    {
                        if (lm.checkDistance(pinchingPos) < goPinchedLH.checkDistance(pinchingPos))
                        {
                            goPinchedLH.endPinch();
                            goPinchedLH = lm;
                            goPinchedLH.startPinch();
                        }
                    }
                }
                return;
            case 1:
                if (goPinchedRH != null)
                {
                    return;
                }
                potentialLayers = new List<LayerMetaphor>();
                gesture = (GesturePinch)gesturePinchRH;
                pinchingPos = gesture.LastTipPos;
                foreach (LayerMetaphor lm in layerMetaphorsActived)
                {
                    if (!lm.IsPinched)
                    {
                        if (lm.checkPinching(pinchingPos))
                        {
                            potentialLayers.Add(lm);
                        }
                    }
                }
                foreach (LayerMetaphor lm in layerMetaphorsDisActived)
                {
                    if (!lm.IsPinched)
                    {
                        if (lm.checkPinching(pinchingPos))
                        {
                            potentialLayers.Add(lm);
                        }
                    }
                }
                if (potentialLayers.Count > 0)
                {
                    goPinchedRH = potentialLayers[0];
                    goPinchedRH.startPinch();
                    foreach (LayerMetaphor lm in potentialLayers)
                    {
                        if (lm.checkDistance(pinchingPos) < goPinchedRH.checkDistance(pinchingPos))
                        {
                            goPinchedRH.endPinch();
                            goPinchedRH = lm;
                            goPinchedRH.startPinch();
                        }
                    }
                }
                return;
        }
    }

    private void OneHandPinching(int mode)
    {
        GesturePinching gesture;
        Vector3 pinchingPos;
        Vector3 posMovement;
        switch (mode)
        {
            case 0:
                gesture = (GesturePinching)gesturePinchingLH;
                pinchingPos = gesture.LastTipPos;
                posMovement = gesture.TipMovement;
                if (goPinchedLH != null)
                {
                    //goPinchedLH.moveObjectBy(posMovement);
                    goPinchedLH.moveObjectTo(pinchingPos);
                    LayerMetaphor lm = (LayerMetaphor)goPinchedLH;
                    bool inRange = handle.updateLayerExisted(lm);
                    if (layerMetaphorsActived.Contains(lm))
                    {
                        if (!inRange)
                        {
                            layerMetaphorsActived.Remove(lm);
                            lm.getLayer().hide();
                            layerMetaphorsDisActived.Add(lm);
                        }
                    }
                    else
                    {
                        if (inRange)
                        {
                            layerMetaphorsActived.Add(lm);
                            lm.getLayer().show();
                            layerMetaphorsDisActived.Remove(lm);
                        }
                    }
                }
                handle.updateObjectsOrder();
                handle.updateObjectsPositions();
                return;
            case 1:
                gesture = (GesturePinching)gesturePinchingRH;
                pinchingPos = gesture.LastTipPos;
                posMovement = gesture.TipMovement;
                Debug.Log(posMovement);
                if (goPinchedRH != null)
                {
                    //goPinchedRH.moveObjectBy(posMovement);
                    goPinchedRH.moveObjectTo(pinchingPos);
                    LayerMetaphor lm = (LayerMetaphor)goPinchedRH;
                    bool inRange = handle.updateLayerExisted(lm);
                    if (layerMetaphorsActived.Contains(lm))
                    {
                        if (!inRange)
                        {
                            layerMetaphorsActived.Remove(lm);
                            lm.getLayer().hide();
                            layerMetaphorsDisActived.Add(lm);
                        }
                    }
                    else
                    {
                        if (inRange)
                        {
                            layerMetaphorsActived.Add(lm);
                            lm.getLayer().show();
                            layerMetaphorsDisActived.Remove(lm);
                        }
                    }
                }
                handle.updateObjectsOrder();
                handle.updateObjectsPositions();
                return;
        }
    }

    private void OneHandTapping(int mode)
    {
        GestureTapping gesture;
        Vector3 tappingPos;
        Vector3 posMovement;
        List<LayerMetaphor> potentialLayers;
        List<SelectionMetaphor> potentialSelections;
        switch (controlMode)
        {
            case ControlMode.tapMenu:
                switch (mode)
                {
                    case 0:
                        gesture = (GestureTapping)gestureTappingLH;
                        tappingPos = gesture.LastTipPos;
                        posMovement = gesture.TipMovement;
                        if (goTappedLH == null)
                        {
                            potentialLayers = new List<LayerMetaphor>();
                            foreach (LayerMetaphor lm in layerMetaphorsActived)
                            {
                                if (!lm.IsTapped)
                                {
                                    if (lm.checkTapping(tappingPos))
                                    {
                                        potentialLayers.Add(lm);
                                    }
                                }
                            }
                            if (potentialLayers.Count > 0)
                            {
                                goTappedLH = potentialLayers[0];
                                foreach (LayerMetaphor lm in potentialLayers)
                                {
                                    if (lm.checkDistance(tappingPos) < goTappedLH.checkDistance(tappingPos))
                                    {
                                        goTappedLH = lm;
                                    }
                                }
                                goTappedLH.startTap();
                                goTappedLH.reScaleWorldObj(1.25f, 1.25f, 1.25f);
                            }
                        }
                        else
                        {
                            if (goTappedLH.checkTapping(tappingPos))
                            {
                                //ratate the go
                            }
                            else
                            {
                                goTappedLH.endTap();
                                goTappedLH.reScaleWorldObj(0.8f, 0.8f, 0.8f);
                                goTappedLH = null;
                            }
                        }
                        return;
                    case 1:
                        gesture = (GestureTapping)gestureTappingRH;
                        tappingPos = gesture.LastTipPos;
                        posMovement = gesture.TipMovement;
                        if (goTappedRH != null)
                        {
                            foreach (SelectionMetaphor sm in goTappedRH.getSelectionObjects())
                            {
                                if (sm.checkTapping(tappingPos))
                                {
                                    goTappedRH.createSelections(sm.getMetaphorObject().name);
                                    return;
                                }
                            }
                        }
                        if (goTappingRH == null)
                        {
                            potentialLayers = new List<LayerMetaphor>();
                            foreach (LayerMetaphor lm in layerMetaphorsActived)
                            {
                                if (lm.checkTapping(tappingPos))
                                {
                                    potentialLayers.Add(lm);
                                }
                            }
                            if (potentialLayers.Count > 0)
                            {
                                goTappingRH = potentialLayers[0];
                                foreach (LayerMetaphor lm in potentialLayers)
                                {
                                    if (lm.checkDistance(tappingPos) < goTappingRH.checkDistance(tappingPos))
                                    {
                                        goTappingRH = lm;
                                    }
                                }
                                goTappingRH.changeTap();
                                if (goTappingRH.IsTapped)
                                {
                                    if(goTappedRH != null)
                                    {
                                        goTappedRH.endTap();
                                        goTappedRH.reColorWorldObj(Color.white);
                                        goTappedRH.removeSelections();
                                    }
                                    goTappedRH = goTappingRH;
                                    goTappedRH.reColorWorldObj(Color.red);
                                    goTappedRH.createSelections();
                                }
                                else
                                {
                                    goTappedRH.reColorWorldObj(Color.white);
                                    goTappedRH.removeSelections();
                                    goTappedRH = null;
                                }
                            }
                        }
                        else
                        {
                            if (goTappingRH.checkTapping(tappingPos))
                            {
                                //do nothing
                            }
                            else
                            {
                                //goTappedRH.endTap();
                                //goTappedRH.reScaleWorldObj(1.25f, 1.25f, 1.25f);
                                goTappingRH = null;
                            }
                        }
                        return;
                }
                return;
            case ControlMode.tappingRotation:
                switch (mode)
                {
                    case 0:
                        gesture = (GestureTapping)gestureTappingLH;
                        tappingPos = gesture.LastTipPos;
                        posMovement = gesture.TipMovement;
                        if (goTappedLH == null)
                        {
                            potentialLayers = new List<LayerMetaphor>();
                            foreach (LayerMetaphor lm in layerMetaphorsActived)
                            {
                                if (!lm.IsTapped)
                                {
                                    if (lm.checkTapping(tappingPos))
                                    {
                                        potentialLayers.Add(lm);
                                    }
                                }
                            }/*
                    foreach (LayerMetaphor lm in layerMetaphorsDisActived)
                    {
                        if (!lm.IsTapped)
                        {
                            if (lm.checkPinching(tappingPos))
                            {
                                potentialLayers.Add(lm);
                            }
                        }
                    }*/
                            if (potentialLayers.Count > 0)
                            {
                                goTappedLH = potentialLayers[0];
                                foreach (LayerMetaphor lm in potentialLayers)
                                {
                                    if (lm.checkDistance(tappingPos) < goTappedLH.checkDistance(tappingPos))
                                    {
                                        goTappedLH = lm;
                                    }
                                }
                                goTappedLH.startTap();
                                goTappedLH.reScaleWorldObj(1.25f, 1.25f, 1.25f);
                            }
                        }
                        else
                        {
                            if (goTappedLH.checkTapping(tappingPos))
                            {
                                //ratate the go
                            }
                            else
                            {
                                goTappedLH.endTap();
                                goTappedLH.reScaleWorldObj(0.8f, 0.8f, 0.8f);
                                goTappedLH = null;
                            }
                        }
                        return;
                    case 1:
                        gesture = (GestureTapping)gestureTappingRH;
                        tappingPos = gesture.LastTipPos;
                        posMovement = gesture.TipMovement;
                        if (goTappedRH == null)
                        {
                            potentialLayers = new List<LayerMetaphor>();
                            foreach (LayerMetaphor lm in layerMetaphorsActived)
                            {
                                if (!lm.IsTapped)
                                {
                                    if (lm.checkTapping(tappingPos))
                                    {
                                        potentialLayers.Add(lm);
                                    }
                                }
                            }/*
                    foreach (LayerMetaphor lm in layerMetaphorsDisActived)
                    {
                        if (!lm.IsTapped)
                        {
                            if (lm.checkPinching(tappingPos))
                            {
                                potentialLayers.Add(lm);
                            }
                        }
                    }*/
                            if (potentialLayers.Count > 0)
                            {
                                goTappedRH = potentialLayers[0];
                                foreach (LayerMetaphor lm in potentialLayers)
                                {
                                    if (lm.checkDistance(tappingPos) < goTappedRH.checkDistance(tappingPos))
                                    {
                                        goTappedRH = lm;
                                    }
                                }
                                goTappedRH.startTap();
                                goTappedRH.reScaleWorldObj(1.25f, 1.25f, 1.25f);
                            }
                        }
                        else
                        {
                            if (goTappedRH.checkTapping(tappingPos))
                            {
                                //ratate the go
                            }
                            else
                            {
                                goTappedRH.endTap();
                                goTappedRH.reScaleWorldObj(0.8f, 0.8f, 0.8f);
                                goTappedRH = null;
                            }
                        }
                        return;
                }
                return;

        }
    }

    private void OneHandEndGrabbing(int mode)
    {
        switch (mode)
        {
            case 0:
                if (goGrabbedLH != null)
                {
                    goGrabbedLH.endGrab();
                }
                goGrabbedLH = null;
                return;
            case 1:
                if (goGrabbedRH != null)
                {
                    goGrabbedRH.endGrab();
                }
                goGrabbedRH = null;
                return;
        }
    }

    private void OneHandEndPinching(int mode)
    {
        switch (mode)
        {
            case 0:
                if (goPinchedLH != null)
                {
                    goPinchedLH.endPinch();
                }
                goPinchedLH = null;
                handle.updateObjectsPositions();
                return;
            case 1:

                if (goPinchedRH != null)
                {

                    goPinchedRH.endPinch();
                }
                goPinchedRH = null;
                handle.updateObjectsPositions();
                return;
        }
    }

    private void OneHandEndTapping(int mode)
    {
        switch (mode)
        {
            case 0:
                if (goTappedLH != null)
                {
                    goTappedLH.endTap();
                    goTappedLH.reScaleWorldObj(0.8f, 0.8f, 0.8f);
                }
                goTappedLH = null;
                return;
            case 1:
                switch (controlMode)
                { 
                    case ControlMode.tapMenu:
                        return;
                    case ControlMode.tappingRotation:
                        if (goTappedRH != null)
                        {
                            goTappedRH.endTap();
                            goTappedRH.reScaleWorldObj(0.8f, 0.8f, 0.8f);
                        }
                        goTappedRH = null;
                        return;
                }
                return;
        }
    }
}
