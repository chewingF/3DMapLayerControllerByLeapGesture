﻿using Mapbox.Unity.MeshGeneration.Data;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapARLayerDup : MapARLayer
{
    private MapARLayer originalLayer;
    private bool highLighted = false;


    public MapARLayerDup(MapARLayer originalLayer)
    {
        this.originalLayer = originalLayer;
        List<GameObject> layerGameObjectsDup = new List<GameObject>();
        List<GameObject> basementGameObjectsDup = new List<GameObject>();
        foreach (GameObject gameObj in originalLayer.getLayerGameObject())
        {
            layerGameObjectsDup.Add(UnityEngine.Object.Instantiate(gameObj, gameObj.transform));
        }
        if (originalLayer.getBaseMentGameObject().Count > 0)
        {
            Material newmaterial = new Material(Shader.Find("Transparent/Diffuse"));
            newmaterial.color = new Color(1f, 1f, 1f, 0.2f);
            foreach (GameObject gameObj in originalLayer.getBaseMentGameObject())
            {
                GameObject newGameObj = UnityEngine.Object.Instantiate(gameObj, gameObj.transform);
                foreach (Transform t in newGameObj.transform)
                {
                    GameObject.Destroy(t.gameObject);
                }
                newGameObj.GetComponent<UnityTile>().enabled = false;
                newGameObj.transform.position = gameObj.transform.position;
                newGameObj.GetComponent<MeshRenderer>().material = newmaterial;
                layerGameObjectsDup.Add(newGameObj);
                basementGameObjectsDup.Add(newGameObj);
            }
        }
        this.setLayerGameObject(layerGameObjectsDup);
        this.setBasementGameObject(basementGameObjectsDup);
    }

    public bool isHighLighted()
    {
        return highLighted;
    }

    public void moveUp(float distance)
    {
        foreach (GameObject gameObj in this.getLayerGameObject())
        {
            Vector3 orgPos = gameObj.transform.position;
            Vector3 trgPos = orgPos;
            trgPos.y += distance;
            gameObj.transform.position = trgPos;
        }
    }

    public override void show()
    {
        base.show();
        originalLayer.show();
    }

    public override void hide()
    {
        base.hide();
        originalLayer.hide();
    }

    public override void setTransparency(float rate)
    {
        base.setTransparency(rate);
        originalLayer.setTransparency(rate);
    }

    public override void setColor(Color color)
    {
        base.setColor(color);
        originalLayer.setColor(color);
    }

    public void destory()
    {
        originalLayer.removeDuplication();
        foreach (GameObject gameObj in this.getLayerGameObject())
        {
            try
            {
                UnityEngine.Object.Destroy(gameObj);
            }
            catch (Exception e)
            {
                Debug.Log(e.ToString());
            }
        }
    }

    public void highLight()
    {
        Material newmaterial = new Material(Shader.Find("Transparent/Diffuse"));
        newmaterial.color = new Color(1f, 1f, 1f, 0.8f);
        foreach (GameObject gameObj in this.getBaseMentGameObject())
        {
            gameObj.GetComponent<MeshRenderer>().material = newmaterial;
        }
        highLighted = true;
    }

    public void cancelHighLight()
    {
        Material newmaterial = new Material(Shader.Find("Transparent/Diffuse"));
        newmaterial.color = new Color(1f, 1f, 1f, 0.2f);
        foreach (GameObject gameObj in this.getBaseMentGameObject())
        {
            gameObj.GetComponent<MeshRenderer>().material = newmaterial;
        }
        highLighted = false;
    }
}
