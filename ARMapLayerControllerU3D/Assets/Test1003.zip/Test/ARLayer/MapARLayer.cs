﻿using Mapbox.Map;
using Mapbox.Unity.Map;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class MapARLayer
{
    private VectorSubLayerProperties vectorSubLayerProperties;
    private string layerName;
    private List<GameObject> layerGameObjects = new List<GameObject>();
    private List<GameObject> basementGameObjects = new List<GameObject>();
    private List<string> layerAttributes;
    private bool visualState = true;
    private MapARLayerDup mapARLayerDup = null;


    public MapARLayer()
    {
    }

    public MapARLayer(VectorSubLayerProperties vslp)
    {
        this.layerName = vslp.coreOptions.layerName;
        this.vectorSubLayerProperties = vslp;
        this.updatLayerGameObjects();
        this.setLayerAttributes();
    }

    public void updatLayerGameObjects()
    {
        foreach (GameObject gameObj in GameObject.FindObjectsOfType<GameObject>().Where(obj => obj.name.Contains(this.layerName)))
        {
            layerGameObjects.Add(gameObj);
        }
    }

    public void updateLayerBasement(List<UnwrappedTileId> tileIDs)
    {
        foreach (UnwrappedTileId id in tileIDs){
            basementGameObjects.Add(GameObject.Find(id.ToString()));
        }
    }

    protected void setLayerName(string layerName)
    {
        this.layerName = layerName;
    }

    protected void setLayerGameObject(List<GameObject> layerGameObjects)
    {
        this.layerGameObjects = layerGameObjects;
    }

    protected void setBasementGameObject(List<GameObject> basementGameObjects)
    {
        this.basementGameObjects = basementGameObjects;
    }

    private void setLayerAttributes()
    {
        layerAttributes = new List<string>();
        //this.layerAttributes.Add("Show/Hide");
        this.layerAttributes.Add("Color");
        this.layerAttributes.Add("Transparency");
        /*
        switch (this.layerName)
        {
            case "road":
                this.layerAttributes.Add("Color");
                this.layerAttributes.Add("Transparency");
                return;
            case "building":
                return;
            case "water":
                this.layerAttributes.Add("Color");
                this.layerAttributes.Add("Transparency");
                return;
        }
        */
    }

    public string getLayerName()
    {
        return layerName;
    }

    public List<GameObject> getLayerGameObject()
    {
        return layerGameObjects;
    }

    public List<GameObject> getBaseMentGameObject()
    {
        return basementGameObjects;
    }

    public MapARLayerDup getDuplication()
    {
        if (this.mapARLayerDup == null)
        {
            this.mapARLayerDup = new MapARLayerDup(this);
        }
        return this.mapARLayerDup;
    }

    public void removeDuplication()
    {
        this.mapARLayerDup = null;
    }

    public bool getVisualState()
    {
        return visualState;
    }

    public List<string> getMapAttributes()
    {
        return layerAttributes;
    }

    public VectorSubLayerProperties GetVectorSubLayerProperties()
    {
        return vectorSubLayerProperties;
    }

    public bool nameIs(string name)
    {
        return this.layerName == name;
    }

    public virtual void changeVisualState()
    {
        if (visualState)
        {
            hide();
        }
        else
        {
            show();
        }
    }

    public virtual void show()
    {
        //this.updatLayerGameObjects();
        if (this.layerGameObjects.Count == 0)
        {
            Debug.Log("No gameobject found with name " + this.layerName);
        }
        else
        {
            foreach (GameObject gameObj in this.layerGameObjects)
            {
                showAll(gameObj);
            }
        }
        visualState = true;
    }

    private void showAll(GameObject gameObj)
    {
        try
        {
            MeshRenderer mr = gameObj.GetComponent<MeshRenderer>();
            if (!mr.enabled)
            {
                mr.enabled = true;
            }
        }
        catch
        {

        }
        foreach (Transform t in gameObj.transform)
        {
            showAll(t.gameObject);
        }
    }

    public virtual void hide()
    {
        //this.updatLayerGameObjects();
        if (this.layerGameObjects.Count == 0)
        {
            Debug.Log("No gameobject found with name " + this.layerName);
        }
        else
        {
            foreach (GameObject gameObj in this.layerGameObjects)
            {
                hideAll(gameObj);
            }
        }
        visualState = false;
    }

    private void hideAll(GameObject gameObj)
    {
        try
        {
            MeshRenderer mr = gameObj.GetComponent<MeshRenderer>();
            if (mr.enabled)
            {
                mr.enabled = false;
            }
        }
        catch
        {

        }
        foreach (Transform t in gameObj.transform)
        {
            hideAll(t.gameObject);
        }
    }

    public virtual void setTransparency(float rate)
    {
        if (this.layerGameObjects.Count == 0)
        {
            Debug.Log("No gameobject found with name " + this.layerName);
        }
        else
        {
            foreach (GameObject gameObj in this.layerGameObjects)
            {
                setAllTransparency(gameObj);
            }
        }
    }

    private void setAllTransparency(GameObject gameObj)
    {
        try
        {
            MeshRenderer mr = gameObj.GetComponent<MeshRenderer>();

            var color = mr.material.color;
            var newColor = new Color(color.r, color.g, color.b, 0.5f);
            mr.material.color = newColor;
        }
        catch
        {
            try
            {
                TextMesh tm = gameObj.GetComponent<TextMesh>();

                var color = tm.color;
                var newColor = new Color(color.r, color.g, color.b, 0.5f);
                tm.color = newColor;
            }
            catch
            {

            }
        }
        foreach (Transform t in gameObj.transform)
        {
            hideAll(t.gameObject);
        }
    }


    public virtual void setColor(Color color)
    {
        if (this.layerGameObjects.Count == 0)
        {
            Debug.Log("No gameobject found with name " + this.layerName);
        }
        else
        {
            foreach (GameObject gameObj in this.layerGameObjects)
            {
                setAllColor(gameObj, color);
            }
        }
    }

    private void setAllColor(GameObject gameObj, Color color)
    {
        try
        {
            MeshRenderer mr = gameObj.GetComponent<MeshRenderer>();
            mr.material.color = color;
        }
        catch
        {
            try
            {
                TextMesh tm = gameObj.GetComponent<TextMesh>();
                tm.color = color;
            }
            catch
            {

            }
        }
        foreach (Transform t in gameObj.transform)
        {
            setAllColor(t.gameObject, color);
        }
    }


    public virtual void destoryAll()
    {
        foreach (GameObject go in layerGameObjects)
        {
            GameObject.Destroy(go);
        }
        layerGameObjects = new List<GameObject>();
    }
}
