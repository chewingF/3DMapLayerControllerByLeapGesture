﻿using Leap;
using Mapbox.Map;
using Mapbox.Unity.MeshGeneration;
using Mapbox.Unity.Map;
using Mapbox.Unity.MeshGeneration.Data;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Mapbox.Unity.MeshGeneration.Factories;
using System.Linq;
using System.Threading;
using System;

public class TestLayerWidget : MonoBehaviour {
    private GameObject mapObj = null;
    private AbstractMap mapToEdit;
    private List<MapARLayer> mapARLayersActived = new List<MapARLayer>();
    private List<MapARLayer> mapARLayersDisActived = new List<MapARLayer>();
    private List<MapARLayerDup> mapARLayersActivedDup = new List<MapARLayerDup>();
    private int currentSelectedIndex = 0;
    private bool Lock = true;//lock other operation when the map is building or animating
    private bool dupActived = false;
    private MenuController menuController= new MenuController();
    private enum FacingTarget{
        LeftMenu,
        Map,
        RightMenu,
        RightMenuSub,
        None
    }

    [SerializeField]
    FacingTarget facingTarget;

    [SerializeField]
    GameObject layerLabel;

    [SerializeField]
    Camera camera;

    [SerializeField]
    float dupGap = 0.3f, dupMovementTime = 0.5f, dupHLGap = 3f, menuGap = 0.3f, leftMenuDegree = -30, rightMenuDegree = 30, rightMenuSubDegree = 60;

    //Leap stuffs
    private Controller controller;
    //gesture models
    LeapGestureModel gestureSplit, gestureClap, 
        gestureLeftSwapLH, gestureRightSwapLH, /*gestureUpSwapLH, gestureDownSwapLH*/gestureUpLongSwapLH, gestureDownLongSwapLH, gestureGrabLH,
        gestureLeftSwapRH, gestureRightSwapRH, /*gestureUpSwapRH, gestureDownSwapRH*/gestureUpLongSwapRH, gestureDownLongSwapRH, gestureGrabRH;

    // Use this for initialization
    void Start () {
        MapLayerInit();
        LeapGestureInit();
    }
	
	// Update is called once per frame
	void Update ()
    {
    }

    private void FixedUpdate()
    {
        TargetUpdate();
        LayerUpdate();
        OnClickListener();
        GestureListener();

    }

    private void MapLayerInit()
    {
        foreach (GameObject gameObj in GameObject.FindObjectsOfType<GameObject>())
        {
            if (gameObj.name == "Map")
            {
                mapObj = gameObj;
            }
        }

        if (mapObj != null)
        {
            mapToEdit = mapObj.GetComponent<AbstractMap>();
            List<VectorSubLayerProperties> mapLayerProperties = (List < VectorSubLayerProperties >) mapToEdit.VectorData.GetAllFeatureSubLayers();
            foreach (VectorSubLayerProperties vsp in mapLayerProperties)
            {

                MapARLayer newLayer = new MapARLayer(vsp);
                if (vsp.coreOptions.isActive)
                {
                    mapARLayersActived.Add(newLayer);
                }
            }
            if (mapARLayersActived.Count != 0)
            {
                layerLabel.GetComponent<TextMesh>().text = ("Current Layer: " + mapARLayersActived[currentSelectedIndex].getLayerName());
            }
            else
            {
                layerLabel.GetComponent<TextMesh>().text = ("No Actived Layer found.");
            }
        }
    }

    private void LeapGestureInit()
    {
        //set up all gesture models
        gestureSplit = new GestureSplit();
        gestureClap = new GestureClap();
        gestureLeftSwapLH = new GestureLeftSwap();
        gestureRightSwapLH = new GestureRightSwap();
        //gestureUpSwapLH = new GestureUpSwap();
        //gestureDownSwapLH = new GestureDownSwap();
        gestureUpLongSwapLH = new GestureUpLongSwap();
        gestureDownLongSwapLH = new GestureDownLongSwap();
        gestureGrabLH = new GestureGrab();
        gestureLeftSwapRH = new GestureLeftSwap();
        gestureRightSwapRH = new GestureRightSwap();
        //gestureUpSwapRH = new GestureUpSwap();
        //gestureDownSwapRH = new GestureDownSwap();
        gestureUpLongSwapRH = new GestureUpLongSwap();
        gestureDownLongSwapRH = new GestureDownLongSwap();
        gestureGrabRH = new GestureGrab();
    }

    //update which trget the camera is looking at
    public void TargetUpdate()
    {
        Vector3 dirCameraRay = camera.transform.forward.normalized;
        Vector3 dirToMap = mapObj.transform.position - camera.transform.position.normalized;
        Vector3 baseSurfaceCross = Vector3.Cross(dirToMap, Vector3.right).normalized;
        Vector3 dirCameraRayOnSurface = Vector3.Cross(Vector3.Cross(baseSurfaceCross,dirCameraRay),baseSurfaceCross).normalized;
        float angle = Vector3.Angle(dirToMap,dirCameraRayOnSurface);
        if (Vector3.Cross(dirToMap,dirCameraRayOnSurface).y < 0) angle = -angle;
        float leftMenuDegree = menuController.getLeftMenuDegree();
        float rightMenuDegree = menuController.getRightMenuDegree();
        float rightMenuSubDegree = menuController.getRightMenuSubDegree();
        FacingTarget oldFacingTarget = facingTarget;
        if (leftMenuDegree*3/2 <= angle & angle < leftMenuDegree/2)
        {
            facingTarget = FacingTarget.LeftMenu;
        } else if (leftMenuDegree/2 <= angle & angle < rightMenuDegree/2)
        {
            facingTarget = FacingTarget.Map;
         } else if (rightMenuDegree/2 <= angle & angle < (rightMenuDegree+rightMenuSubDegree)/2) 
        {
            facingTarget = FacingTarget.RightMenu;
        }else if ((rightMenuDegree + rightMenuSubDegree) / 2 <= angle & angle < (rightMenuDegree/2 + rightMenuSubDegree*3/2))
        {
            facingTarget = FacingTarget.RightMenuSub;
        }
        else
        {
            facingTarget = FacingTarget.None;
        }
        if (oldFacingTarget != facingTarget)
        {
            switch (facingTarget)
            {
                case FacingTarget.None:
                    menuController.WatchOn(-1);
                    return;
                case FacingTarget.Map:
                    menuController.WatchOn(-1);
                    return;
                case FacingTarget.LeftMenu:
                    menuController.WatchOn(0);
                    return;
                case FacingTarget.RightMenu:
                    menuController.WatchOn(1);
                    return;
                case FacingTarget.RightMenuSub:
                    menuController.WatchOn(2);
                    return;
            }
        }
    }

    //update layer gameobject content when map initialized , moved.
    private void LayerUpdate()
    {
        //check initialized
        var visualizer = mapToEdit.MapVisualizer;
        visualizer.OnMapVisualizerStateChanged += (s) =>
        {

            if (this == null)
                return;

            if (s == ModuleState.Finished)
            {
                if (this.Lock)
                {
                    List<UnwrappedTileId> tileIds = mapToEdit.MapVisualizer.ActiveTiles.Keys.ToList();
                    foreach (MapARLayer layer in this.mapARLayersActived)
                    {
                        layer.updateLayerGameObjects();
                        layer.updateLayerBasement(tileIds);
                    }
                    this.Lock = false;
                }
            }
            else if (s == ModuleState.Working)
            {
                this.Lock = true;
            }
        };
    }

    private void GestureListener()
    { //not editable when building
        if (this.Lock)
        {
            return;
        }
        else
        {
            controller = new Controller();
            Frame frame = controller.Frame();
            List<Hand> hands = frame.Hands;
            Hand leftHand = new Hand();
            bool leftHandExist = false;
            Hand rightHand = new Hand();
            bool rightHandExist = false;
            foreach (Hand hand in hands)
            {
                if (hand.IsLeft)
                {
                    leftHand = hand;
                    leftHandExist = true;
                }
                else
                {
                    rightHand = hand;
                    rightHandExist = true;
                }
            }
            if (dupActived)
            {
                //Two-Hands Gestures
                if (leftHandExist & rightHandExist)
                {
                    if (gestureClap.Check(leftHand, rightHand, Time.deltaTime) == LeapGestureModel.State.End)
                    {
                        TwoHandsClap();
                    }
                }
                //One-Hand Gestures for Left Hand
                else if (leftHandExist & !rightHandExist)
                {
                    if ((gestureRightSwapLH.Check(leftHand, null, Time.deltaTime) == LeapGestureModel.State.End))
                    {
                        OneHandRightSwap();
                    }
                    if ((gestureLeftSwapLH.Check(leftHand, null, Time.deltaTime) == LeapGestureModel.State.End))
                    {
                        OneHandLeftSwap();
                    }/*
                    if ((gestureUpSwapLH.Check(leftHand, null, Time.deltaTime) == LeapGestureModel.State.End))
                    {
                        OneHandUpSwap();
                    }
                    if ((gestureDownSwapLH.Check(leftHand, null, Time.deltaTime) == LeapGestureModel.State.End))
                    {
                        OneHandDownSwap();
                    }*/
                    if ((gestureUpLongSwapLH.Check(leftHand, null, Time.deltaTime) == LeapGestureModel.State.InProcess))
                    {
                        OneHandUpSwap((GestureUpLongSwap)gestureUpLongSwapLH);
                    }
                    if ((gestureDownLongSwapLH.Check(leftHand, null, Time.deltaTime) == LeapGestureModel.State.InProcess))
                    {
                        OneHandDownSwap((GestureDownLongSwap)gestureDownLongSwapLH);
                    }
                    if ((gestureGrabLH.Check(leftHand, null, Time.deltaTime) == LeapGestureModel.State.End))
                    {
                        OneHandGrab();
                    }
                }
                //One0Hand Gestures for Right Hand
                else if (!leftHandExist & rightHandExist)
                {
                    if ((gestureRightSwapRH.Check(null, rightHand, Time.deltaTime) == LeapGestureModel.State.End))
                    {
                        OneHandRightSwap();
                    }
                    if ((gestureLeftSwapRH.Check(null, rightHand, Time.deltaTime) == LeapGestureModel.State.End))
                    {
                        OneHandLeftSwap();
                    }/*
                    if ((gestureUpSwapRH.Check(null, rightHand, Time.deltaTime) == LeapGestureModel.State.End))
                    {
                        OneHandUpSwap();
                    }
                    if ((gestureDownSwapRH.Check(null, rightHand, Time.deltaTime) == LeapGestureModel.State.End))
                    {
                        OneHandDownSwap();
                    }*/
                    if ((gestureUpLongSwapRH.Check(null, rightHand, Time.deltaTime) == LeapGestureModel.State.InProcess))
                    {
                        OneHandUpSwap((GestureUpLongSwap)gestureUpLongSwapRH);
                    }
                    if ((gestureDownLongSwapRH.Check(null, rightHand, Time.deltaTime) == LeapGestureModel.State.InProcess))
                    {
                        OneHandDownSwap((GestureDownLongSwap)gestureDownLongSwapRH);
                    }
                    if ((gestureGrabRH.Check(null, rightHand, Time.deltaTime) == LeapGestureModel.State.End))
                    {
                        OneHandGrab();
                    }
                }
            }
            else
            {
                if (leftHandExist & rightHandExist)
                {
                    //check gesture models states
                    if (gestureSplit.Check(leftHand, rightHand, Time.deltaTime) == LeapGestureModel.State.End)
                    {
                        TwoHandsSplit();
                    }
                }
            }
        }
    }

    private void OnClickListener()
    {
        //not editable when building
        if (this.Lock)
        {
            return;
        }
        else
        {
            if (dupActived)
            {
                if (Input.GetKeyDown(KeyCode.I))
                {
                    print("key I is held down");
                    Invisual();
                }
                if (Input.GetKeyDown(KeyCode.V))
                {
                    print("key V is held down");
                    Visual();
                }
                if (Input.GetKeyDown(KeyCode.T))
                {
                    print("key T is held down");
                    setTransparency(0.5f);
                }
                if (Input.GetKeyDown(KeyCode.N))
                {
                    print("key N is press down");
                    MapLayerSelectNext();
                }
                if (Input.GetKeyDown(KeyCode.M))
                {
                    print("key M is press down");
                    TwoHandsClap();
                }
                if (Input.GetKeyDown(KeyCode.RightArrow))
                {
                    print("key right Arrow is press down");
                    OneHandRightSwap();
                }
                if (Input.GetKeyDown(KeyCode.LeftArrow))
                {
                    print("key left Arrow is press down");
                    OneHandLeftSwap();
                }
                if (Input.GetKeyDown(KeyCode.UpArrow))
                {
                    print("key up Arrow is press down");
                    //OneHandUpSwap();
                }
                if (Input.GetKeyDown(KeyCode.DownArrow))
                {
                    print("key down Arrow is press down");
                    //OneHandDownSwap();
                }
                if (Input.GetKeyDown(KeyCode.G))
                {
                    print("key G is press down");
                    OneHandGrab();
                }
                if (Input.GetKeyDown(KeyCode.A))
                {
                    print("key A is held down");
                    try{
                        AddLayer(mapARLayersDisActived[0]);
                    }
                    catch
                    {
                        Debug.Log("No Layer to be added");
                    }
                }
                if (Input.GetKeyDown(KeyCode.D))
                {
                    print("key D is held down");
                    try { 
                        DeleteLayer(mapARLayersActived[currentSelectedIndex]);
                    }
                    catch
                    {
                        Debug.Log("No Layer to be Delete");
                    }
                }
            }
            else
            {
                if (Input.GetKeyDown(KeyCode.M))
                {
                    print("key M is press down");
                    TwoHandsSplit();
                }
            }
        }
    }

    //==============================Gestures Methods================================
    private void TwoHandsClap()
    {
        DuplicateClose();
        menuController.RightMenuClose();
        menuController.RightMenuSubClose();
        menuController.LeftMenuClose();
    }

    private void TwoHandsSplit()
    {
        Duplicate();
        LeftMenuSetUp();
        menuController.WatchOn(-1);
    }

    private void OneHandUpSwap(GestureUpLongSwap gesture)
    {
        if (!gesture.SwapLevelAdded)
        {
            return;
        }
        switch (facingTarget)
        {
            case FacingTarget.LeftMenu:
                LeftMenuSelectNext();
                return;
            case FacingTarget.Map:
                MapLayerSelectNext();
                return;
            case FacingTarget.RightMenu:
                RightMenuSelectNext();
                return;
            case FacingTarget.RightMenuSub:
                RightMenuSubSelectNext();
                return;
        }
    }

    private void OneHandDownSwap(GestureDownLongSwap gesture)
    {
        if (!gesture.SwapLevelAdded)
        {
            return;
        }
        switch (facingTarget)
        {
            case FacingTarget.LeftMenu:
                LeftMenuSelectLast();
                return;
            case FacingTarget.Map:
                MapLayerSelectLast();
                return;
            case FacingTarget.RightMenu:
                RightMenuSelectLast();
                return;
            case FacingTarget.RightMenuSub:
                RightMenuSubSelectLast();
                return;
        }
    }

    private void OneHandRightSwap()
    {
        switch (facingTarget)
        {
            case FacingTarget.LeftMenu:
                //LeftMenuClose();
                LeftMenuSelect();
                return;
            case FacingTarget.Map:
                MapLayerSelect();
                return;
            case FacingTarget.RightMenu:
                RightMenuSelect();
                return;
        }
    }

    private void OneHandLeftSwap()
    {
        switch (facingTarget)
        {
            case FacingTarget.Map:
                if (menuController.isLefttMenuOn())
                {
                    DeleteLayer(mapARLayersActived[currentSelectedIndex]);
                    LeftMenuRefresh();
                    menuController.WatchOn(-1);
                }
                else
                {
                    LeftMenuSetUp();
                }
                return;
            case FacingTarget.RightMenu:
                RightMenuClose();
                return;
            case FacingTarget.RightMenuSub:
                RightMenuSubClose();
                return;
        }
    }

    private void OneHandGrab()
    {
        switch (facingTarget)
        {
            case FacingTarget.LeftMenu:
                LeftMenuSelect();
                return;
            case FacingTarget.Map:
                MapLayerSelect();
                return;
            case FacingTarget.RightMenu:
                RightMenuSelect();
                return;
            case FacingTarget.RightMenuSub:
                RightMenuSubSelect();
                return;
        }
    }

    //=============================Detailed commands methods=================================
    private void RightMenuSetUp()
    {
        List<string> rightMenuItems = mapARLayersActived[currentSelectedIndex].getMapAttributes();
        menuController.RightMenuCreate("Propertity",rightMenuItems, camera.transform, rightMenuDegree, menuGap);
    }

    private void RightMenuSubSetUp(string CMD)
    {
        List<string> rightMenuSubItems = new List<string>();
        switch (CMD)
        {
            case "Color":
                rightMenuSubItems.Add("Red");
                rightMenuSubItems.Add("Black");
                rightMenuSubItems.Add("Yellow");
                menuController.RightMenuSubCreate("Color",rightMenuSubItems, camera.transform, rightMenuSubDegree, menuGap);
                return;
            case "Transparency":
                rightMenuSubItems.Add("25%");
                rightMenuSubItems.Add("50%");
                rightMenuSubItems.Add("75%");
                rightMenuSubItems.Add("100%");
                menuController.RightMenuSubCreate("Transparency", rightMenuSubItems, camera.transform, rightMenuSubDegree, menuGap);
                return;
        }
    }

    private void LeftMenuSetUp()
    {
        List<string> leftMenuItems = new List<string>();
        foreach(MapARLayer layer in mapARLayersDisActived){
            leftMenuItems.Add(layer.getLayerName());
        }
        menuController.LeftMenuCreate("Other Layers", leftMenuItems, camera.transform, leftMenuDegree, menuGap);
    }

    private void RightMenuRefresh()
    {
        List<string> rightMenuItems = mapARLayersActived[currentSelectedIndex].getMapAttributes();
        menuController.RightMenuRefresh(rightMenuItems);
        RightMenuSubRefresh(menuController.getRightMenuCMD());
    }
    
    private void RightMenuSubRefresh(string CMD)
    {
        List<string> rightMenuSubItems = new List<string>();
        switch (CMD)
        {
            case "Color":
                rightMenuSubItems.Add("Red");
                rightMenuSubItems.Add("Black");
                rightMenuSubItems.Add("Yellow");
                menuController.RightMenuSubRefresh(rightMenuSubItems);
                return;
            case "Transparency":
                rightMenuSubItems.Add("25%");
                rightMenuSubItems.Add("50%");
                rightMenuSubItems.Add("75%");
                rightMenuSubItems.Add("100%");
                menuController.RightMenuSubRefresh(rightMenuSubItems);
                return;
        }
    }

    private void LeftMenuRefresh()
    {
        List<string> leftMenuItems = new List<string>();
        foreach (MapARLayer layer in mapARLayersDisActived)
        {
            leftMenuItems.Add(layer.getLayerName());
        }
        menuController.LeftMenuRefresh(leftMenuItems);
    }

    private void RightMenuClose()
    {
        menuController.RightMenuClose();

        menuController.RightMenuSubClose();
    }

    private void RightMenuSubClose()
    {
        menuController.RightMenuSubClose();
    }

    private void LeftMenuClose()
    {
        menuController.LeftMenuClose();
    }

    /*private void MapLayerSelectNext(int level)
    {
        int boundary = this.mapARLayersActived.Count - 1 - currentSelectedIndex;
        if (boundary < level)
        {
            level = boundary;
        }
        this.currentSelectedIndex += level;
        // all up one
        foreach (MapARLayerDup layerDup in mapARLayersActivedDup)
        {
            StartCoroutine(DuplicationMovement(layerDup, Vector3.down, level * dupGap, level * dupMovementTime, 1));
        }
        MapHightLightUpdate();
        RightMenuRefresh();
    }*/
    private void MapLayerSelectNext()
    {
        if (this.currentSelectedIndex < mapARLayersActivedDup.Count -1)
        {
            this.currentSelectedIndex += 1;
            // all drop one
            foreach (MapARLayerDup layerDup in mapARLayersActivedDup)
            {
                StartCoroutine(DuplicationMovement(layerDup, Vector3.down, dupGap, dupMovementTime, 1));
            }
        }/*
        else
        {
            this.currentSelectedIndex = 0;
        }*/
        MapHightLightUpdate();
        RightMenuRefresh();
        menuController.WatchOn(-1);
    }

    private void RightMenuSelectNext()
    {
        menuController.RightMenuSelectNext();
        RightMenuSubRefresh(menuController.getRightMenuCMD());
        menuController.WatchOn(1);
    }

    private void RightMenuSubSelectNext()
    {
        menuController.RightMenuSubSelectNext();
    }
    private void LeftMenuSelectNext()
    {
        menuController.LeftMenuSelectNext();
    }

    private void MapLayerSelectLast()
    {
        if (this.currentSelectedIndex > 0)
        {
            this.currentSelectedIndex -= 1;
            // all up one
            foreach (MapARLayerDup layerDup in mapARLayersActivedDup)
            {
                StartCoroutine(DuplicationMovement(layerDup, Vector3.up, dupGap, dupMovementTime, 1));
            }
        }/*
        else
        {
            this.currentSelectedIndex = (this.mapARLayersActived.Count - 1);
        }*/
        MapHightLightUpdate();
        RightMenuRefresh();
        menuController.WatchOn(-1);
    }

    private void RightMenuSelectLast()
    {
        menuController.RightMenuSelectLast();
        RightMenuSubRefresh(menuController.getRightMenuCMD());
        menuController.WatchOn(1);
    }

    private void RightMenuSubSelectLast()
    {
        menuController.RightMenuSubSelectLast();
    }

    private void LeftMenuSelectLast()
    {
        menuController.LeftMenuSelectLast();
    }

    private void MapLayerSelect()
    {
        RightMenuSetUp();
        menuController.WatchOn(-1);
    }

    private void RightMenuSelect()
    {
        string selectedCMD = menuController.getRightMenuCMD();
        Debug.Log(selectedCMD);
        switch (selectedCMD)
        {
            case "Show/Hide":
                HideOrShow();
                return;
            case "Color":
                RightMenuSubSetUp(selectedCMD);
                menuController.WatchOn(1);
                return;
            case "Transparency":
                RightMenuSubSetUp(selectedCMD);
                menuController.WatchOn(1);
                return;
        }
    }

    private void RightMenuSubSelect()
    {
        string selectedCMD = menuController.getRightMenuSubCMD();
        Debug.Log(selectedCMD);
        switch (selectedCMD)
        {
            case "Red":
                setColor(Color.red);
                return;
            case "Black":
                setColor(Color.black);
                return;
            case "Yellow":
                setColor(Color.yellow);
                return;
            case "25%":
                setTransparency(.25f);
                return;
            case "50%":
                setTransparency(.50f);
                return;
            case "75%":
                setTransparency(.75f);
                return;
            case "100%":
                setTransparency(1f);
                return;
        }
    }

    private void LeftMenuSelect()
    {
        string selectedCMD = menuController.getLeftMenuCMD();
        Debug.Log(selectedCMD);
        foreach(MapARLayer layer in mapARLayersDisActived)
        {
            if (layer.nameIs(selectedCMD))
            {
                AddLayer(layer);
                LeftMenuRefresh();
                MapHightLightUpdate();
                return;
            }
        }
    }

    private void AddLayer(MapARLayer layer)
    {
        MapARLayerDup mapARLayerDup = layer.getDuplication();
        mapARLayerDup.show();
        mapARLayersActived.Insert(0, layer);
        mapARLayersDisActived.Remove(layer);
        StartCoroutine(DuplicationMovement(mapARLayerDup, Vector3.up, dupGap * 5, dupMovementTime, 1));
        mapARLayersActivedDup.Insert(currentSelectedIndex, mapARLayerDup);
        foreach (MapARLayerDup layerDup in mapARLayersActivedDup)
        {
            if (mapARLayersActivedDup.IndexOf(layerDup) > currentSelectedIndex)
            {
                StartCoroutine(DuplicationMovement(layerDup, Vector3.up, dupGap, dupMovementTime, 1));
            }
        }
        MapHightLightUpdate();
    }

    private void DeleteLayer(MapARLayer layer)
    {
        MapARLayerDup mapARLayerDup = layer.getDuplication();
        mapARLayersActived.Remove(layer);
        mapARLayersDisActived.Insert(0, layer);
        StartCoroutine(DuplicationMovement(mapARLayerDup, Vector3.down, dupGap * 5, dupMovementTime, 1));
        mapARLayersActivedDup.Remove(mapARLayerDup);
        //mapARLayerDup.destory(); 
        foreach (MapARLayerDup layerDup in mapARLayersActivedDup)
        {
            if (mapARLayersActivedDup.IndexOf(layerDup)>=currentSelectedIndex)
            {
                StartCoroutine(DuplicationMovement(layerDup, Vector3.down, dupGap, dupMovementTime, 1));
            }
        }
        mapARLayerDup.hide();
        MapHightLightUpdate();
    }

    private void MapHightLightUpdate()
    {
        if (currentSelectedIndex >= mapARLayersActived.Count)
        {
            currentSelectedIndex = mapARLayersActived.Count - 1;
        }
        if(currentSelectedIndex<0 && mapARLayersActived.Count > 0)
        {
            currentSelectedIndex = 0;
        }
        if (layerLabel != null)
        {
            if (currentSelectedIndex >= 0)
            {
                layerLabel.GetComponent<TextMesh>().text = ("Current Layer: " + mapARLayersActived[currentSelectedIndex].getLayerName());
                foreach (MapARLayerDup layerDup in mapARLayersActivedDup) 
                {
                    if (layerDup.isHighLighted())
                    {
                        StartCoroutine(DuplicationMovement(layerDup, Vector3.forward, dupHLGap, dupMovementTime
                            , 1));
                        layerDup.cancelHighLight();
                    }
                    layerDup.showSelf();
                    if ((currentSelectedIndex - mapARLayersActivedDup.IndexOf(layerDup) > 2))
                    {
                        layerDup.hideSelf();
                        }
                }
                try
                {
                    mapARLayersActivedDup[currentSelectedIndex].highLight();
                    StartCoroutine(DuplicationMovement(mapARLayersActivedDup[currentSelectedIndex], -Vector3.forward, dupHLGap, dupMovementTime
                        , 1));
                }
                catch
                {
                }
            }
            else
            {
                layerLabel.GetComponent<TextMesh>().text = ("No Layer on the Map ");
            }
        }
    }

    //=====================Functional methods==========================
    private void HideOrShow()
    {
        if (mapARLayersActivedDup[currentSelectedIndex].getVisualState())
        {
            Invisual();
        }
        else
        {
            Visual();
        }
    }

    private void Visual()
    {
        mapARLayersActivedDup[currentSelectedIndex].show();
    }

    private void Invisual()
    {
        mapARLayersActivedDup[currentSelectedIndex].hide();
    }

    private void setTransparency(float rate)
    {
        mapARLayersActivedDup[currentSelectedIndex].setTransparency(rate);
    }

    private void setColor(Color color)
    {
        mapARLayersActivedDup[currentSelectedIndex].setColor(color);
    }

    public void Duplicate()
    {
        //get all duplication
        foreach (MapARLayer layer in mapARLayersActived)
        {
            mapARLayersActivedDup.Add(layer.getDuplication());
        }
        //move up all duplication
        float distance = (5-currentSelectedIndex) * dupGap;
        foreach (MapARLayerDup layerDup in mapARLayersActivedDup)
        {
            StartCoroutine(DuplicationMovement(layerDup, Vector3.up, distance, dupMovementTime, 1));
            distance += dupGap;
        }
        MapHightLightUpdate();
        dupActived = true;
    }

    public void DuplicateClose()
    {
        //move back all duplication
        float distance = (currentSelectedIndex - 5) * dupGap;
        foreach (MapARLayerDup layerDup in mapARLayersActivedDup)
        {
            if (layerDup.isHighLighted())
            {
                StartCoroutine(DuplicationMovement(layerDup, Vector3.forward, dupHLGap, dupMovementTime
                    , 1));
                layerDup.cancelHighLight();
            }
            StartCoroutine(DuplicationMovement(layerDup, Vector3.up, distance, dupMovementTime
                , 2));
            distance -= dupGap;
        }
        //clean data
        mapARLayersActivedDup.Clear();
        dupActived = false;
    }

    private IEnumerator DuplicationMovement(MapARLayerDup targetLayer, Vector3 movementDirection, float movementDistance, float movementTime, int mode)
    {
        //this.Lock = true;
        for (float t = 0.0f; t < movementTime;)
        {
            float td = Time.deltaTime;
            //targetLayer.moveUp(movementDistance * Time.deltaTime / movementTime);
            targetLayer.moveTowards(movementDirection, movementDistance * Time.deltaTime / movementTime);
            t += td;
            yield return null;
        }
        if (mode == 2)
        {
            targetLayer.destory();
        }
        //this.Lock = false;
    }
    
}
