﻿using Mapbox.Unity.MeshGeneration.Data;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapARLayerDup : MapARLayer
{
    private MapARLayer originalLayer;
    private bool highLighted = false;


    public MapARLayerDup(MapARLayer originalLayer)
    {
        this.originalLayer = originalLayer;
        List<GameObject> layerGameObjectsDup = new List<GameObject>();
        List<GameObject> basementGameObjectsDup = new List<GameObject>();
        foreach (GameObject gameObj in originalLayer.getLayerGameObject())
        {
            layerGameObjectsDup.Add(UnityEngine.Object.Instantiate(gameObj, gameObj.transform));
        }
        Material newmaterial = new Material(Shader.Find("Transparent/Diffuse"));
        newmaterial.color = new Color(1f, 1f, 1f, 0.05f);
        foreach (GameObject gameObj in originalLayer.getBaseMentGameObject())
        {
            GameObject newGameObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            newGameObj.transform.parent = gameObj.transform.parent;
            newGameObj.transform.position = gameObj.transform.position;
            newGameObj.transform.localScale = gameObj.transform.localScale;
            newGameObj.GetComponent<Renderer>().material = newmaterial;
            GameObject.Destroy(newGameObj.GetComponent<BoxCollider>());
            MeshFilter mf = newGameObj.GetComponent<MeshFilter>();
            mf.mesh = gameObj.GetComponent<MeshFilter>().mesh;
            /*GameObject newGameObj = UnityEngine.Object.Instantiate(gameObj, gameObj.transform);
            foreach (Transform t in newGameObj.transform)
            {
                GameObject.Destroy(t.gameObject);
            }
            newGameObj.GetComponent<UnityTile>().enabled = false;
            newGameObj.transform.position = gameObj.transform.position;
            newGameObj.GetComponent<MeshRenderer>().material = newmaterial;*/
            //layerGameObjectsDup.Add(newGameObj);
            basementGameObjectsDup.Add(newGameObj);
        }

        this.setLayerGameObject(layerGameObjectsDup);
        this.setBasementGameObject(basementGameObjectsDup);
    }

    public bool isHighLighted()
    {
        return highLighted;
    }

    public void moveUp(float distance)
    {
        foreach (GameObject gameObj in this.getLayerGameObject())
        {
            Vector3 orgPos = gameObj.transform.position;
            Vector3 trgPos = orgPos;
            trgPos.y += distance;
            gameObj.transform.position = trgPos;
        }
        foreach (GameObject gameObj in this.getBaseMentGameObject())
        {
            Vector3 orgPos = gameObj.transform.position;
            Vector3 trgPos = orgPos;
            trgPos.y += distance;
            gameObj.transform.position = trgPos;
        }
    }

    public void moveTowards(Vector3 direction, float distance)
    {
        direction = direction.normalized;
        foreach (GameObject gameObj in this.getLayerGameObject())
        {
            Vector3 orgPos = gameObj.transform.position;
            Vector3 trgPos = orgPos + direction * distance;
            gameObj.transform.position = trgPos;
        }
        foreach (GameObject gameObj in this.getBaseMentGameObject())
        {
            Vector3 orgPos = gameObj.transform.position;
            Vector3 trgPos = orgPos + direction * distance;
            gameObj.transform.position = trgPos;
        }
    }

    public override void show()
    {
        showSelf();
        originalLayer.show();
    }

    public override void hide()
    {
        hideSelf();
        originalLayer.hide();
    }

    public void showSelf()
    {
        foreach (GameObject gameObj in this.getLayerGameObject())
        {
            showAll(gameObj);
        }
        foreach (GameObject gameObj in this.getBaseMentGameObject())
        {
            showAll(gameObj);
        }
    }

    private void showAll(GameObject gameObj)
    {
        try
        {
            MeshRenderer mr = gameObj.GetComponent<MeshRenderer>();
            if (!mr.enabled)
            {
                mr.enabled = true;
            }
        }
        catch
        {

        }
        foreach (Transform t in gameObj.transform)
        {
            showAll(t.gameObject);
        }
    }
    public void hideSelf()
    {
        foreach (GameObject gameObj in this.getLayerGameObject())
        {
            hideAll(gameObj);
        }
        foreach (GameObject gameObj in this.getBaseMentGameObject())
        {
            hideAll(gameObj);
        }
    }

    private void hideAll(GameObject gameObj)
    {
        try
        {
            MeshRenderer mr = gameObj.GetComponent<MeshRenderer>();
            if (mr.enabled)
            {
                mr.enabled = false;
            }
        }
        catch
        {

        }
        foreach (Transform t in gameObj.transform)
        {
            hideAll(t.gameObject);
        }
    }

    public override void setTransparency(float rate)
    {
        setSelfTransparency(rate);
        originalLayer.setTransparency(rate);
    }
    
    public void setSelfTransparency(float rate)
    {
        foreach (GameObject gameObj in this.getLayerGameObject())
        {
            setAllTransparency(gameObj, rate);
        }
    }
    private void setAllTransparency(GameObject gameObj, float rate)
    {
        try
        {
            MeshRenderer mr = gameObj.GetComponent<MeshRenderer>();
            foreach(Material m in mr.materials)
            {
                var color = m.color;
                var newColor = new Color(color.r, color.g, color.b, rate);
                m.color = newColor;
            }
        }
        catch
        {
        }
        foreach (Transform t in gameObj.transform)
        {
            setAllTransparency(t.gameObject, rate);
        }
    }

    public override void setColor(Color color)
    {
        setSelfColor(color);
        originalLayer.setColor(color);
    }

    public void setSelfColor(Color color)
    {
        foreach (GameObject gameObj in this.getLayerGameObject())
        {
            setAllColor(gameObj, color);
        }
    }

    private void setAllColor(GameObject gameObj, Color color)
    {
        try
        {
            MeshRenderer mr = gameObj.GetComponent<MeshRenderer>();
            foreach (Material m in mr.materials)
            {
                float a = m.color.a;
                color.a = a;
                m.color = color;
            }
        }
        catch
        {
        }
        foreach (Transform t in gameObj.transform)
        {
            setAllColor(t.gameObject, color);
        }
    }

    public void destory()
    {
        originalLayer.removeDuplication();
        foreach (GameObject gameObj in this.getLayerGameObject())
        {
            try
            {
                UnityEngine.Object.Destroy(gameObj);
            }
            catch (Exception e)
            {
                Debug.Log(e.ToString());
            }
        }
        foreach (GameObject gameObj in this.getBaseMentGameObject())
        {
            try
            {
                UnityEngine.Object.Destroy(gameObj);
            }
            catch (Exception e)
            {
                Debug.Log(e.ToString());
            }
        }
    }
    

    public void highLight()
    {
        Material newmaterial = new Material(Shader.Find("Transparent/Diffuse"));
        newmaterial.color = new Color(1f, 1f, 1f, 0.8f);
        foreach (GameObject gameObj in this.getBaseMentGameObject())
        {
            gameObj.GetComponent<MeshRenderer>().material = newmaterial;
        }
        highLighted = true;
    }

    public void cancelHighLight()
    {
        Material newmaterial = new Material(Shader.Find("Transparent/Diffuse"));
        newmaterial.color = new Color(1f, 1f, 1f, 0.05f);
        foreach (GameObject gameObj in this.getBaseMentGameObject())
        {
            gameObj.GetComponent<MeshRenderer>().material = newmaterial;
        }
        highLighted = false;
    }
}
