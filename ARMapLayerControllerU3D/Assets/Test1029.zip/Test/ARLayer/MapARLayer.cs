﻿using Mapbox.Map;
using Mapbox.Unity.Map;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class MapARLayer
{
    private VectorSubLayerProperties vectorSubLayerProperties;
    private string layerName;
    private List<GameObject> layerGameObjects = new List<GameObject>();
    private List<GameObject> basementGameObjects = new List<GameObject>();
    private List<string> layerAttributes;
    private bool visualState = true;
    private MapARLayerDup mapARLayerDup = null;


    public MapARLayer()
    {
    }

    public MapARLayer(VectorSubLayerProperties vslp)
    {
        this.layerName = vslp.coreOptions.sublayerName;//layerName;
        this.vectorSubLayerProperties = vslp;
        this.updateLayerGameObjects();
        this.setLayerAttributes();
    }
    
    public void updateLayerGameObjects()
    {
        foreach (GameObject gameObj in GameObject.FindObjectsOfType<GameObject>().Where(obj => obj.name.Contains(this.layerName)))
        {
            layerGameObjects.Add(gameObj);
        }
    }

    public void updateLayerBasement(List<UnwrappedTileId> tileIDs)
    {
        foreach (UnwrappedTileId id in tileIDs){
            basementGameObjects.Add(GameObject.Find(id.ToString()));
        }
    }

    protected void setLayerName(string layerName)
    {
        this.layerName = layerName;
    }
    
    protected void setLayerGameObject(List<GameObject> layerGameObjects)
    {
        this.layerGameObjects = layerGameObjects;
    }
    
    protected void setBasementGameObject(List<GameObject> basementGameObjects)
    {
        this.basementGameObjects = basementGameObjects;
    }

    private void setLayerAttributes()
    {
        layerAttributes = new List<string>();
        //this.layerAttributes.Add("Show/Hide");
        this.layerAttributes.Add("Color");
        this.layerAttributes.Add("Transparency");
        /*
        switch (this.layerName)
        {
            case "road":
                this.layerAttributes.Add("Color");
                this.layerAttributes.Add("Transparency");
                return;
            case "building":
                return;
            case "water":
                this.layerAttributes.Add("Color");
                this.layerAttributes.Add("Transparency");
                return;
        }
        */
    }

    public string getLayerName()
    {
        return layerName;
    }
    
    public List<GameObject> getLayerGameObject()
    {
        return layerGameObjects;
    }
    
    public List<GameObject> getBaseMentGameObject()
    {
        return basementGameObjects;
    }

    public MapARLayerDup getDuplication()
    {
        if (this.mapARLayerDup == null)
        {
            this.mapARLayerDup = new MapARLayerDup(this);
        }
        return this.mapARLayerDup;
    }

    public void removeDuplication()
    {
        this.mapARLayerDup = null;
    }

    public bool getVisualState()
    {
        return visualState;
    }

    public List<string> getMapAttributes()
    {
        return layerAttributes;
    }

    public VectorSubLayerProperties GetVectorSubLayerProperties()
    {
        return vectorSubLayerProperties;
    }

    public bool nameIs(string name)
    {
        return this.layerName == name;
    }

    public virtual void changeVisualState()
    {
        if (visualState)
        {
            hide();
        }
        else
        {
            show();
        }
    }

    public virtual void show()
    {
        vectorSubLayerProperties.SetActive(true);
        visualState = true;
    }

    public virtual void hide()
    {
        vectorSubLayerProperties.SetActive(false);
        visualState = false;
    }

    public virtual void setTransparency(float rate)
    {
        Color c = vectorSubLayerProperties.Texturing.ColorStyle.FeatureColor;
        c.a = rate;
        vectorSubLayerProperties.Texturing.ColorStyle.FeatureColor = c;
        vectorSubLayerProperties.coreOptions.HasChanged = true;
        /**/
    }
    /*
    */

    public virtual void setColor(Color color)
    {
        float a = vectorSubLayerProperties.Texturing.ColorStyle.FeatureColor.a;
        color.a = a;
        vectorSubLayerProperties.Texturing.ColorStyle.FeatureColor = color;
        vectorSubLayerProperties.coreOptions.HasChanged = true;
        /**/
    }
    /*
    */
    /*
    public virtual void destoryAll()
    {
        foreach (GameObject go in layerGameObjects)
        {
            GameObject.Destroy(go);
        }
        layerGameObjects = new List<GameObject>();
    }*/
    
}
