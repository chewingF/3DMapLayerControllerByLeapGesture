using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leap.Unity.Interaction;
using UnityEngine.Events;

public class LockRotation : MonoBehaviour
{
    protected InteractionBehaviour _intObj;

    private void Start()
    {
        _intObj = GetComponent<InteractionBehaviour>();
        _intObj.OnGraspedMovement += onGraspedMovement;
    }

    private void Update()
    {
        //gameObject.transform.rotation = new Quaternion(0,0,0,0);
    }


    private void onGraspedMovement(Vector3 presolvePos, Quaternion presolveRot,
                                   Vector3 solvedPos, Quaternion solvedRot,
                                   List<InteractionController> controllers)
    { 
        _intObj.rigidbody.position = solvedPos;
        _intObj.rigidbody.rotation = presolveRot;
        Debug.Log("presolvePos" + solvedPos);
    }
}
