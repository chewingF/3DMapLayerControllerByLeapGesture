﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HandleMetaphor:TouchableObject{
    
    private List<LayerMetaphor> layers = new List<LayerMetaphor>();
    private GameObject baseObject;
    private float generalGap = 0.05f;
    private int maxShow = 5;
    private int centerIndex = 0;
    private int centerTopIndex = 0;
    private int centerBotIndex = 0;
    private List<int> centerAroundIndexs = new List<int>();
    private float crowedRate = 0.5f;

    public HandleMetaphor(GameObject handleGo)
    {
        worldObject = handleGo;
        foreach (Transform t in handleGo.transform)
        {
            if (t.name == "Base")
            {
                baseObject = t.gameObject;
                Debug.Log("Base found");
            }
        }
    }

    public void addLayer(LayerMetaphor layer)
    {
        try
        {
            GameObject layerObject = layer.getMetaphorObject();
            layerObject.transform.parent = baseObject.transform.parent;
        }
        catch
        {
            Debug.Log("Fail to set layer parent");
            return;
        }
        layers.Add(layer);
    }

    public void removeLayer(LayerMetaphor layer)
    {
        try
        {
            GameObject layerObject = layer.getMetaphorObject();
            layerObject.transform.parent = worldObject.transform.parent;
        }
        catch
        {
            Debug.Log("Fail to set layer parent");
            return;
        }
        layers.Remove(layer);
    }

    public void updateIndex(Vector3 handPos)
    {
        Vector3 handlePos = getMetaphorObject().transform.position;
        float distance = Vector2.Distance(new Vector2(handPos.x, handPos.z), new Vector2(handlePos.x, handlePos.z));
        //bool inRange = (distance <= pinchingRange * 2);
        bool inRange = (distance <= baseObject.transform.GetComponent<CapsuleCollider>().radius * baseObject.transform.lossyScale.x * 2) ;
        if (!inRange)
        {
            return;
        }
        centerAroundIndexs.Clear();
        centerIndex = 0;
        centerTopIndex = 0;
        centerBotIndex = 0;
        if (layers.Count == 0)
        {
            return;
        }
        else if (layers.Count == 1)
        {
            centerAroundIndexs.Add(0);
        }
        else if (layers.Count <= maxShow)
        {
            Vector3 firstLayerPos = baseObject.transform.position + Vector3.up * generalGap;
            Vector3 lastLayerPos = firstLayerPos + Vector3.up *generalGap *  (layers.Count-1);
            centerIndex = Mathf.RoundToInt((handPos.y - firstLayerPos.y) / (lastLayerPos.y - firstLayerPos.y) * (layers.Count - 1));
            centerBotIndex = 0;
            centerTopIndex = layers.Count - 1;
            for(int i = 0; i < layers.Count; i++)
            {
                centerAroundIndexs.Add(i);
            }
        }
        else
        {
            Vector3 firstLayerPos = baseObject.transform.position + Vector3.up * generalGap;
            Vector3 lastLayerPos = firstLayerPos + Vector3.up * generalGap * (maxShow - 1 + (layers.Count - maxShow) * crowedRate);
            //Debug.Log("Step1: firstLayerPos" + firstLayerPos);
            //Debug.Log("Step1: lastLayerPos" + lastLayerPos);
            //Debug.Log("Step1: handPos" + handPos);
            centerIndex = Mathf.RoundToInt((handPos.y - firstLayerPos.y) / (lastLayerPos.y - firstLayerPos.y) * (layers.Count - 1));
            //Debug.Log("Step2: centerIndex draft" + centerIndex);
            if (centerIndex < 0)
            {
                centerIndex = 0;
            }else if (centerIndex > layers.Count - 1)
            {
                centerIndex = layers.Count - 1;
            }
            //Debug.Log("Step3: centerIndex" + centerIndex);
            centerBotIndex = centerIndex;
            centerTopIndex = centerIndex;
            int count = 0;
            while (centerAroundIndexs.Count < maxShow)
            {
                count++;
                if (count%2 == 0)
                {
                    int nextAround = centerIndex - count/2;
                    if (nextAround >= 0 && nextAround < layers.Count)
                    {
                        centerBotIndex = nextAround;
                        centerAroundIndexs.Add(nextAround);
                    }
                }
                else
                {
                    int nextAround = centerIndex + count/2;
                    if (nextAround >= 0 && nextAround < layers.Count)
                    {
                        centerTopIndex = nextAround;
                        centerAroundIndexs.Add(nextAround);
                    }
                }
            }
        }
        //Debug.Log("bot:" + centerBotIndex + "center" + centerIndex + "top" + centerTopIndex);
    }

    public void updateObjectsPositions()
    {
        int i = 0;
        foreach (LayerMetaphor layer in layers){
            i++;
            if (centerAroundIndexs.Contains(i))
            {
                layer.reScaleOrginal();
            }
            else
            {
                layer.reScaleCrowed();
            }
            if (!layer.IsPinched)
            {
                layer.moveObjectTo(postionForLayerInIndex(i));
            }
        }
    }

    private Vector3 postionForLayerInIndex(int i)
    {
        Vector3 newPos = new Vector3();
        newPos = baseObject.transform.position;
        if (layers.Count <= maxShow)
        {
            newPos += Vector3.up * generalGap * (i + 1);
        }
        else
        {
            if (centerBotIndex == 0)
            {
                if (centerAroundIndexs.Contains(i))
                {
                    newPos += Vector3.up * generalGap * (i + 0.5f);
                }
                else
                {
                    newPos += Vector3.up * generalGap * (maxShow - 1 + (i - maxShow + 2) * crowedRate);
                }
            }
            else if (centerTopIndex == layers.Count - 1)
            {
                if (centerAroundIndexs.Contains(i))
                {
                    newPos += Vector3.up * generalGap * (i - layers.Count + maxShow + (layers.Count - maxShow + 1) * crowedRate);
                }
                else
                {
                    newPos += Vector3.up * generalGap * (i + 1) * crowedRate;
                }
            }
            else
            {
                if (i < centerBotIndex)
                {
                    newPos += Vector3.up * generalGap * (i + 1) * crowedRate;
                }
                else if (i <= centerTopIndex)
                {
                    newPos += Vector3.up * generalGap * (i - centerBotIndex + (centerBotIndex + 1) * crowedRate);
                }
                else
                {
                    newPos += Vector3.up * generalGap * (maxShow - 1 + (i - maxShow + 2) * crowedRate);
                }
            }
        }
        return newPos;
    }

    public bool updateLayerExisted(LayerMetaphor lm)
    {
        Vector3 lmPos = lm.getMetaphorObject().transform.position;
        Vector3 handlePos = getMetaphorObject().transform.position;
        float distance = Vector2.Distance(new Vector2(lmPos.x, lmPos.z), new Vector2(handlePos.x, handlePos.z));
        //bool inRange = (distance <= pinchingRange * 2);
        bool inRange = (distance <= baseObject.transform.GetComponent<CapsuleCollider>().radius * baseObject.transform.lossyScale.x);
        if (layers.Contains(lm))
        {
            if (!inRange)
            {
                removeLayer(lm);
            }
        }
        else
        {
            if (inRange)
            {
                addLayer(lm);
            }
        }
        return inRange;
    }

    public void updateObjectsOrder()
    {
        List<LayerMetaphor> newLayers = new List<LayerMetaphor>();
        for(int i = 0; i < layers.Count-1
            ; i++)
        {
            for(int j = i+1; j < layers.Count; j++)
            {
                if(layers[j].getMetaphorObject().transform.position.y < layers[i].getMetaphorObject().transform.position.y)
                {
                    LayerMetaphor temp = layers[j];
                    layers[j] = layers[i];
                    layers[i] = temp;
                }
            }
        }
    }
}
